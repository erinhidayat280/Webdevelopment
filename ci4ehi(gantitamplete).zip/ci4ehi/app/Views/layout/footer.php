<footer>
<script src="<?php echo base_url('assets/js/jquery-3.js')?>" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
      <script>window.jQuery || document.write('<script src="/docs/4.6/assets/js/vendor/jquery.slim.min.js"><\/script>')</script><script src="<?php echo base_url('assets/js/bootstrap.js')?>" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>

      
        <script src="<?php echo base_url('assets/js/feather.js')?>"></script>
        <script src="<?php echo base_url('assets/js/Chart.js')?>"></script>
        <script src="<?php echo base_url('assets/js/dashboard.js')?>"></script>

</footer></html>