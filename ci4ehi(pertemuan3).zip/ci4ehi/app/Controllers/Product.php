<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\product_model;


class Product extends BaseController
{
	public function index()
	{

		$model = new product_model();
		$data['product'] = $model->getProduct()->getResult();

		echo view('layout/header');
		echo view('view_product', $data);
		echo view('layout/footer');
	}
	public function input()
	{

		$model = new product_model();
		$data['satuan'] = $model->getSatuan()->getResult();

		echo view('form', $data);
	}

	public function save()
	{
		$model = new Product_model();
		$data = array('name_product' => $this->request->getPost('namabarang'),
		'beli_product' => $this->request->getPost('hargabeli'),
		'jual_product' => $this->request->getPost('hargajual'),
		'stok_product' => $this->request->getPost('stokproduk'),
		'satuan_id' => $this->request->getPost('satuanproduk'),
		'ket_product' => $this->request->getPost('keterangan'),
	);
	$model->saveProduct($data);
	return redirect()->to('/product');
	}
	public function delete()
	{
		$model = new Product_model();
		$id = $this->request->getPost('id_product');
		$model->deleteProduct($id);
		return redirect()->to('/product');
	
	}
}
