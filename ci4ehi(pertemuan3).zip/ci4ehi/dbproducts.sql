-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 08, 2021 at 11:39 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbproducts`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id_product` int(11) UNSIGNED NOT NULL,
  `name_product` varchar(255) NOT NULL,
  `beli_product` double DEFAULT NULL,
  `jual_product` double NOT NULL,
  `stok_product` int(5) NOT NULL,
  `satuan_id` int(11) UNSIGNED NOT NULL,
  `ket_product` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id_product`, `name_product`, `beli_product`, `jual_product`, `stok_product`, `satuan_id`, `ket_product`) VALUES
(1, 'Signature Hitam', 155000, 165000, 100, 101, 'Rokok'),
(2, 'Sampoerna Mild', 220000, 230000, 100, 101, 'Rokok'),
(3, 'Garam Filter', 165000, 175000, 100, 101, 'Rokok'),
(4, 'Djarum Super', 170000, 180000, 100, 101, 'Rokok'),
(5, 'Djarum Coklat', 120000, 130000, 100, 101, 'Rokok'),
(6, 'Tepung Terigu', 5000, 6500, 200, 102, 'Tepung Terigu'),
(7, 'Tepung Beras', 9000, 12000, 200, 102, 'Tepung Beras'),
(8, 'Tepung Ketan', 10000, 13000, 200, 102, 'Tepung Ketan'),
(9, 'Bawang Merah', 14000, 16000, 200, 102, 'Bawang Merah'),
(10, 'Bawang Putih', 13000, 17000, 200, 102, 'Bawang Putih'),
(11, 'Taro', 120000, 15000, 150, 103, 'Makanan Ringan'),
(12, 'Komo', 80000, 90000, 150, 103, 'Makanan Ringan'),
(13, 'Jaguar', 85000, 95000, 150, 103, 'Makanan Ringan'),
(14, 'Tiktak', 75000, 80000, 150, 103, 'Makanan Ringan'),
(15, 'Beras Putih', 9500, 11500, 500, 104, 'Sembako'),
(16, 'Minyak Curah', 16000, 19000, 250, 104, 'Sembako'),
(17, 'Beras Merah', 11000, 13000, 500, 104, 'Sembako'),
(18, 'Gula Pasir', 10000, 12000, 500, 104, 'Sembako'),
(19, 'Minyak Bimoli', 18000, 20000, 250, 104, 'Sembako'),
(20, 'Kentang Goreng', 25000, 28000, 250, 103, 'Makanan Ringan'),
(28008, 'Signatur Blue', 155000, 165000, 100, 101, 'Rokok');

-- --------------------------------------------------------

--
-- Table structure for table `satuans`
--

CREATE TABLE `satuans` (
  `id_satuan` int(11) UNSIGNED NOT NULL,
  `name_satuan` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `satuans`
--

INSERT INTO `satuans` (`id_satuan`, `name_satuan`) VALUES
(101, 'Slop'),
(102, 'Kilogram'),
(103, 'Bal'),
(104, 'Liter');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id_product`);

--
-- Indexes for table `satuans`
--
ALTER TABLE `satuans`
  ADD PRIMARY KEY (`id_satuan`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id_product` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28009;

--
-- AUTO_INCREMENT for table `satuans`
--
ALTER TABLE `satuans`
  MODIFY `id_satuan` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=123006;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
